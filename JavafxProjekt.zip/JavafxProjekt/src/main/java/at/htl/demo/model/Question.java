package at.htl.demo.model;

public class Question {

    private String answer;

    public Question(String answer) {
        this.answer = answer;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
